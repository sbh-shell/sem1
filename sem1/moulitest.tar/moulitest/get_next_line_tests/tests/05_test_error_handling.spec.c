UT_ASSERT_EQ(get_next_line(1, NULL), -1);
UT_ASSERT_EQ(get_next_line(99, NULL), -1);
