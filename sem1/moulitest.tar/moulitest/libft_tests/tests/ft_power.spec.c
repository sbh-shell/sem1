UT_ASSERT_EQ(ft_power(2, 3), pow(2, 3));
UT_ASSERT_EQ(ft_power(10, 9), pow(10, 9));
UT_ASSERT_EQ(ft_power(50, 0), pow(50, 0));
UT_ASSERT_EQ(ft_power(0, 10), pow(0, 10));
UT_ASSERT_EQ(ft_power(25, 13), pow(25,13));